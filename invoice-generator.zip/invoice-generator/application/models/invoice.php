<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Invoice { 

var $url = '';
private $email = '';
public $mail_body = '';
public $subject = '';
public $cc = '';

function __construct() {
		$this->url = "http://".$_SERVER['HTTP_HOST'].'/';
		$this->email = 'neethu@stepsonweb.com';
}
function get_current_time() {
	date_default_timezone_set('Asia/Kolkata');
	$now=date("Y-m-d H:i:s");
	return $now;
}

function get_current_date() {
	date_default_timezone_set('Asia/Kolkata');
	$now=date("Y-m-d");
	return $now;
}

function dateDiff($beginDate, $endDate)
{
    $diff = abs(strtotime($endDate) - strtotime($beginDate));
    return ceil($diff / 86400);
}

function getUniqueID($length=4){
        $random= ""; 
        srand((double)microtime()*1000000); 
        $data = "AbcDE123IJKLMN67QRSTUVWXYZ"; 
        $data .= "aBCdefghijklmn123opq45rs67tuv89wxyz"; 
        $data .= "0FGH45OP89"; 
        for($i = 0; $i < $length; $i++) 
        { 
         $random .= substr($data, (rand()%(strlen($data))), 1); 
        } 
        return $random.date("ymd"); 
}

function getExtension($str) {
	$i = strrpos($str,".");
    if (!$i) { return ""; }
    $l = strlen($str) - $i;
    $ext = substr($str,$i+1,$l);
    return $ext;
}
function send_mail($data,$email,$subject,$user='admin') {
	$this->subject=$subject." | Escmanager";
	$url = $this->url;

	$this->mail_body='<html>
	<head>
	</head>	
	<body>
<table width="100%" border="0" cellspacing="0">
  <tr>
    <td align="center" valign="top">
    <font face="Arial, Helvetica, sans-serif" size="-1" color="#333333">
    <table width="610" border="1" bordercolor="#CCCCCC" cellpadding="10" cellspacing="0" style="border-collapse:collapse">
      <tr>
        <td bgcolor="#FAFAFA"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
          <tr>
            <td width="587" height="104" align="center" valign="top" background="'.$url.'assets/images/logo.png"><table width="95%" border="0" cellspacing="0">
              <tr>
                <td height="70">&nbsp;</td>
              </tr>
              <tr>
                <td align="right"><font color="#FFFFFF">Hi '.$user.'</font></td>
              </tr>
            </table></td>
          </tr>
          <tr>
            <td valign="top"><table width="100%" border="0" cellpadding="10" cellspacing="0">
              <tr>
                <td><p>'.$subject.' are mentioned below.</p>';
				foreach($data as $key =>$val) {
				$this->mail_body.= '<p>'.ucwords(strtolower($key)).' : '.$val.'</p>';
				}
				 $this->mail_body.='</td>
                </tr>
              </table>             </td>
          </tr>
        </table></td>
      </tr>
    </table><table width="600" border="0" cellspacing="0">
  <tr>
    <td height="10" align="center"></td>
  </tr>
  <tr>
    <td align="center"><font size="0" color="#666666">
      Copyright &copy; 2013 <a href="http://escmanager.in/">escmanager.in</a>. All rights reserved.</font></td>
  </tr>
</table>

   </font> 
   </td>
  </tr>
</table>
</body>
	</html>';
	return $this->send($email);
}

function send($emails) {
	//print_r($emails);exit;
  $headers = 'MIME-Version: 1.0' . "\r\n";
  $headers.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
  $headers.= 'From:Escmanager <noreply@escmanager.in>' . "\r\n";
  $headers.= $this->cc;
  $sent = false;
  if ( ! is_array($emails))	$emails = [$emails];
  foreach($emails as $email) {
   if(mail($email, $this->subject,$this->mail_body, $headers)) $sent = true;
   
  }
   return $sent;
}

function send_forgot_mail($email,$validate,$name,$page) {
	//echo $name;exit;
	$this->subject='Forgot Password | escmanager';
	$url = $this->url;
	 $emails = 'esc.1@europestudycentre.com';
	//$emails = 'neethu@stepsonweb.com';
	$this->mail_body='<html>
	<head>
	</head>	
	<body>
<table width="100%" border="0" cellspacing="0">
  <tr>
    <td align="center" valign="top">
    <font face="Arial, Helvetica, sans-serif" size="-1" color="#333333">
    <table width="610" border="1" bordercolor="#CCCCCC" cellpadding="10" cellspacing="0" style="border-collapse:collapse">
      <tr>
        <td bgcolor="#FAFAFA"><table width="100%" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
          <tr>
            <td width="587" height="104" align="center" valign="top" background="'.$url.'assets/images/logo.png"><table width="95%" border="0" cellspacing="0">
              <tr>
                <td height="70">&nbsp;</td>
              </tr>
              <tr>
                <td align="right"><font color="#FFFFFF">Hi '.ucfirst(strtolower($name)).'</font></td>
              </tr>
            </table></td>
          </tr>
		  <tr><td>USER NAME: '.$name.'</td></tr>
          <tr>
		 
            <td valign="top"><table width="100%" border="0" cellpadding="10" cellspacing="0">
              <tr>
                <td><p>We have received a request to reset the password. To reset password, click on the link given below</p>
                  <p><a href="'.$url.'logged/resetpwd/'.$page.'/'.$validate.'" target="_blank">Click Here </a> to reset password</p>
                  <p>Best regards,<br />
                    <strong><strong>GSP Team</strong></strong></p></td>
                </tr>   
              </table>             </td>
          </tr>
        </table></td>
      </tr>
    </table><table width="600" border="0" cellspacing="0">
  <tr>
    <td height="10" align="center"></td>
  </tr>
  <tr>
    <td align="center"><font size="0" color="#666666">
      Copyright � 2013 <a href="http://escmanager-qatar.com/">escmanager-qatar.com</a>. All rights reserved.</font></td>
  </tr>
</table>

   </font> 
   </td>
  </tr>
</table>
</body>
	</html>';
	//$this->send($email);
	return $this->send($emails);
}


function humanTiming ($time)

{ 

    date_default_timezone_set('Asia/Kolkata');

	$time = time() - $time; // to get the time since that moment



    $tokens = array (

        31536000 => 'year',

        2592000 => 'month',

        604800 => 'week',

        86400 => 'day',

        3600 => 'hour',

        60 => 'minute',

        1 => 'second'

    );



    foreach ($tokens as $unit => $text) {

        if ($time < $unit) continue; 

        $numberOfUnits = floor($time / $unit);

		

        return $numberOfUnits.' '.$text.(($numberOfUnits>1)?'s':'').' ago';

    }

}
function file_upload($uploadfile,$upload_directory) {
			if (copy($upload_directory.'temp/'.$uploadfile, $upload_directory . $uploadfile)) {
			unlink($upload_directory.'temp/'.$uploadfile);
                        if($upload_directory=='assets/institutes/gallery/')
                        $this->resize_image($uploadfile,$upload_directory,185,136,'thumb/',false);
               return true;

            }
			  return false;
} 

function resize_image($resize,$loc,$width,$height,$thumb='',$heighe_auto=true){

  $filename = $loc.$resize;
   $jpeg_quality = 75;
	list($width_orig, $height_orig, $type) = getimagesize($filename);
	if($heighe_auto==true) {
         $proportional = $width_orig/$height_orig;
	 $height = $width / $proportional;
	}

	

// Resample

	$image_p = imagecreatetruecolor($width, $height);

	if($type==2) {
     $image = imagecreatefromjpeg($filename);
	 imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);
	 imagejpeg($image_p,$loc.$thumb.$resize,$jpeg_quality);
	}
   elseif($type==3) {
     $image = imagecreatefrompng($filename);
	 imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);
	imagejpeg($image_p,$loc.$thumb.$resize,$jpeg_quality);
   }
   elseif($type==0) {
     $image = imagecreatefromgif($filename);
	 imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width_orig, $height_orig);
	imagegif($image_p,$loc.$thumb.$resize,$jpeg_quality);
   }
	 
	
}

function watermarkImage($SourceFile, $WaterMarkText, $DestinationFile,$bottom=false) { 

   list($width, $height, $type) = getimagesize($SourceFile);

   $image_p = imagecreatetruecolor($width, $height);

   if($type==2)

     $image = imagecreatefromjpeg($SourceFile);

   elseif($type==3)

     $image = imagecreatefrompng($SourceFile);

   imagecopyresampled($image_p, $image, 0, 0, 0, 0, $width, $height, $width, $height); 

   $white = imagecolorallocatealpha ($image_p, 255, 255, 255,75);

   $black = imagecolorallocatealpha ($image_p, 0, 0, 0,75);

   $font = './system/fonts/texb.ttf';

	   $font_size = 10;

   if($width>350){

	   $font_size = 13;

   }

  

   $type_space = imagettfbbox($font_size, 0, $font, $WaterMarkText);

   

   $image_width = abs($type_space[4] - $type_space[0]) + 10;

   $image_height = abs($type_space[5] - $type_space[1]) + 10;   

   
    $dest_x    = ($width/ 2) - ($image_width/2);
  if($bottom==true) {
    $dest_y    = ($height/2) - ($image_height/2);
  }
  else {
    $dest_x    = ($width/ 2);
	$dest_y    = ($height - 5);
  }


   imagettftext($image_p, $font_size, 0, $dest_x+1, $dest_y+1, $black, $font, $WaterMarkText);

   imagettftext($image_p, $font_size, 0, $dest_x, $dest_y, $white, $font, $WaterMarkText);

   

   if ($DestinationFile!='') {

     if($type==2)

      imagejpeg ($image_p, $DestinationFile, 100);

	 elseif($type==3)

	  imagepng ($image_p, $DestinationFile, 100);

   } else {

      header('Content-Type: image/jpeg');

      imagejpeg($image_p, null, 100);

   };

   imagedestroy($image); 

   imagedestroy($image_p); 

}

function paginationfile($url,$data,$no=10) {
	    $config['base_url'] = $url;		
		$config['total_rows'] = $data['count'];
		$config['per_page'] = $no;
		$config['num_links'] = 15;
		$config['first_link'] = '';
		$config['last_link'] = '';
		$config['next_tag_open'] = '<li class="next">';
		$config['next_tag_close'] = '</li>';
		$config['prev_tag_open'] = '<li class="previous">';
		$config['prev_tag_close'] = '</li>';
		$config['next_link']  = 'Next';
		$config['prev_link'] = 'Previous';
		$config['cur_tag_open'] = '<li class="active"><a href="javascript:void(0);">';
		$config['cur_tag_close'] = '</a></li>';
		$config['full_tag_open'] = '<ul class="pagination">';
		$config['full_tag_close'] = '</ul>';
		$config['num_tag_open'] = '<li>';
		$config['num_tag_close'] = '</li>';
		return $config;
}




function send_webinar_mail($data) {
	print_r($data);exit;
	$this->subject=$data['title'];
	$url = $this->url;
	$subject = "Webinar details";


$this->mail_body = $data['webinar'];

	 
	return $this->send($data['mailids']);
}


function send_webinar_mail_limited_user($data) {
//print_r($data);echo '<br/>';exit;
	$this->subject=$data['Title'];
	$url = $this->url;
	
	
	

/*	$this->mail_body='<html>
	<head>
	</head>	
	<body>
<table width="100%" border="0" cellspacing="0">
 
          <tr>
            <td valign="top"><table width="100%" border="0" cellpadding="10" cellspacing="0">
              <tr>
                <td><p>'.$data['Title'].' are mentioned below.</p></td>
				
                </tr>
				<tr><td>Title</td><td>'.$data['Title'].'</td></tr>
				<tr><td>Date</td><td>'.$data['Date'].'</td></tr>
				<tr><td>Time</td><td>'.$data['Time'].'</td></tr>
				<tr><td>Location</td><td>'.$data['Location'].'</td></tr>
				<tr><td>Registration Link</td><td>'.$data['Registration Link'].'</td></tr>
				
              </table>             </td>
          </tr>
        </table></td>
      </tr>
    </table><table width="600" border="0" cellspacing="0">
  <tr>
    <td height="10" align="center"></td>
  </tr>
  <tr>
    <td align="center"><font size="0" color="#666666">
      Copyright &copy; 2013 <a href="http://escmanager.in/">escmanager.in</a>. All rights reserved.</font></td>
  </tr>
</table>

   </font> 
   </td>
  </tr>
</table>
</body>
	</html>';
	*/
	$this->mail_body = '<table style="border: 1px solid #ccc;
  border-collapse: collapse;
  margin: 0;
  padding: 0;
  width: 50%;
  table-layout: fixed;">
  <caption style="font-size: 1.5em;
  margin: .5em 0 .75em;font-size: 1.3em;">Webinar Details</caption>
   <caption>Webinar Name: '.$data['Title'].'</caption>
  <thead>
    <tr style="background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;">
      <th style="padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase; border: 1px solid black;" scope="col">Title</th>
  <td style="padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;border: 1px solid black;" scope="col">'.$data['Title'].'</td>
  </tr>
  <tr style="background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;">
      <th style="border: 1px solid black;padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;" scope="col">Date</th>
  <td style="border: 1px solid black;padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;" scope="col">'.$data['Location'].'</td>
  </tr>
  <tr style="background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;">
      <th style="border: 1px solid black;padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;" scope="col">Time</th>
  <td style="border: 1px solid black;padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;" scope="col">'.$data['Time'].'</td>
  </tr>
  <tr style="background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;">
      <th style="border: 1px solid black;padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;" scope="col">Location</th>
  <td style="border: 1px solid black;padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;" scope="col">'.$data['Title'].'</td>
    </tr>
	<tr style="background-color: #f8f8f8;
  border: 1px solid #ddd;
  padding: .35em;">
      <th style="border: 1px solid black;padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;" scope="col">Registration Link</th>
  <td style="border: 1px solid black;padding: .625em;
  text-align: center;font-size: .85em;
  letter-spacing: .1em;
  text-transform: uppercase;" scope="col">'.$data['Registration Link'].'</td>
    </tr>
  </thead>
</table>';
	
	//echo $this->mail_body;exit;
	//echo $data['admin_user'];exit;
	return $this->send($data['admin_user']);
}


}

?>