<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class invoice_model extends CI_Model {
	var $_date = '';	
	function __construct() {
		parent::__construct();		
		$this->_date = $this->invoice->get_current_time();
	}		
	function add_with_check($data,$table,$check) { // function for check existing while inserting data 
		$res = $this->totalcount($table, $check);
		if ($res == 0) {
			$data = $this->add_data($data,$table);
		}	
		else {
			$data['resultmsg'] = '<h4 class="alert_error">Sorry, already exist</h4>';	
		}	
		return $data;	
	}
	function totalcount($table, $where) { // return total count of rows
		$this->db->where($where);
		$res = $this->db->get($table);
		$total_rows = $res->num_rows();
		return $total_rows;
	}
	protected function add_data($data,$table) {	
		$data['entry_date'] = $this->_date;
		$data['status'] = 1;
		if($this->required_date_status==true) {
			$data['entry_date'] = $this->_date;	
			if(!isset($data['status'])) {
				$data['status'] = 1;
			}
		}
		if($this->insert_to($table, $data)) {
			foreach($data as $key =>$val) {
				$data[$key] = '';
			}	
			unset($_POST);
			$data['timeout'] = true;
			$data['time_out'] = true;	     
			$data['resultmsg'] = '<h4 class="alert_success">Added Successfully</h4>';
		}
		else {
		$data['resultmsg'] = '<h4 class="alert_error">Try again..</h4>';
		}
		return $data;
	}
	function add_without_check($data,$table) { // fdo not check existing while inserting data
		$data = $this->add_data($data,$table);
		return $data;
	}
	function insert_to($table, $data) {	
		$data = $this->security->xss_clean($data);	
		if($this->db->insert($table, $data)) {
			return true;	
		}
		return false;
	}
	function update_value($table,$where,$data) {
		$data = $this->security->xss_clean($data);
		 if($this->db->update($table, $data, $where)) {
			 return true;
		 }	  else	   return false;
	} 
	function get_where_from($where,$table,$field,$field_tmp='',$offset=0,$limit=1,$order='ASC',$by='id') {
		
		// get particular data from table with where condition
		$this->db->select($field);
	$this->db->limit($limit,$offset);
	$this->db->order_by($by, $order);	 $field = ($field_tmp=='')?$field:$field_tmp;	 $query = $this->db->get_where($table, $where);	 foreach($field as $select) {    		$data[$select] = '';	 }	 	foreach ($query->result() as $row)		{		  foreach($field as $select) {    		  $data[$select] = $row->$select;		  }		}		return $data;	}
	
	function get_where_from_all($where,$table,$field,$order,$by='ASC',$offset='',$limit='') {
		// get all data from table with where condition

		 $this->db->select($field);
		 $this->db->order_by($order, $by);
		 if($limit!='') {	 
		 $this->db->limit($limit,$offset); 	 
		 }	 $this->db->where($where);	
		 $res = $this->db->get_where($table);	
//echo $this->db->last_query();	//	 exit;
		 return $res;	}	
		 
}