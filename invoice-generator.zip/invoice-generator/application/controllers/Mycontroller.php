<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mycontroller extends CI_Controller {
function __construct(){
	parent::__construct();
}
function common_add_edit($data) { // common function for post form inputs
	foreach($data as $key =>$field) {
		if(is_array($this->input->post($field)))
			$data[$key] = ($this->input->post($field))?$this->input->post($field):[];
		else
			$data[$key] = ($this->input->post($field))?trim($this->input->post($field)):"";
	}
	return $data;
}
function common_assign($data) { // common function for form validation
	$valid = [];
	$count = 0;
	foreach($data as $key =>$val) {
		$valid[$count]['field'] = $key;
		$valid[$count]['label'] = ucwords(str_replace('_', ' ', $key));
		//$valid[$count]['rules'] = 'filter_tags|'.$val;
		$valid[$count]['rules'] = $val;
		$count++;
	}
	return $valid;
}
function validation_assign() { // common function for  set message and set rules for form validation
	$this->load->library('form_validation');
	$this->form_validation->set_rules($this->valid);
	$this->form_validation->set_message(['required' => 'has-error','valid_email' => 'has-error']);
	$this->form_validation->set_error_delimiters('', '');		
}

}