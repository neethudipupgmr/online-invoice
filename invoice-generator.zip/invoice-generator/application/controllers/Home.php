<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
require('Mycontroller.php');
class Home extends Mycontroller {
	function __construct()
	{
	parent::__construct();
		$this->load->library('form_validation');
	}
	public function index() {
		$data = $this->common_add_edit(['company_name' =>'company_name','company_address'=>'company_address','company_phone'=>'company_phone','company_email'=>'company_email','customer_name'=>'customer_name','customer_address'=>'customer_address','customer_phone'=>'customer_phone','customer_email'=>'customer_email','title'=>'title','invoice_date'=>'invoice_date']);
		$this->load->view('home',$data);
	}
	public function form_action(){ //function for submit form data
		
		$data = $this->common_add_edit(['company_name' =>'company_name','company_address'=>'company_address','company_phone'=>'company_phone','company_email'=>'company_email','customer_name'=>'customer_name','customer_address'=>'customer_address','customer_phone'=>'customer_phone','customer_email'=>'customer_email','title'=>'title','invoice_date'=>'invoice_date','discount_type'=>'discount_type','discount_value'=>'discount_value','discount_value_amount'=>'discount_value_amount']);
		
		$item_name = $this->input->post('item_name');
		$item_quantity = $this->input->post('item_quantity');
       	$item_price = $this->input->post('item_price');
       	$item_tax = $this->input->post('item_tax');
		
	
		
		$this->valid = $this->common_assign(['company_name' =>'required','company_address'=>'required','company_phone'=>'required','customer_name'=>'required','customer_address'=>'required','invoice_date'=>'required','company_email'=>'required','customer_phone'=>'required']);
		$data['invoice_id'] = $this->invoice->getUniqueID();
		$data = $this->add($data,'invoice_info');
		if($data['time_out']){ 
			 $id = $this->db->insert_id(); //get last inserted id
			
		
		
     $item['invoice_id'] = $id;
 		foreach ($item_name as $key => $value ) 
        { 
            $item['item_name'] = $value;
           
            $item['item_quantity'] = $item_quantity[$key];
			$item['item_price'] = $item_price[$key];
			$item['item_tax'] = $item_tax[$key];
			
          $data =   $this->invoice_model->insert_to('more_info',$item);
			
        }
				
		}
		
		redirect('home/generate/'.$id);
		
		
	}
	function generate($invoice_id){ 
		
		//display invoice page
		
		
		$where = ['id' => $invoice_id];

	   $field = ['id','company_name','company_address','company_phone','company_email','customer_name','customer_address','customer_phone','customer_email','title','invoice_date','discount_type','discount_value','discount_value_amount','invoice_id'];

	   $data = $this->invoice_model->get_where_from($where,'invoice_info',$field);	   
$fields = ['item_name','item_quantity','item_price','item_tax'];
		$data['res'] = $this->invoice_model->get_where_from_all(['invoice_id'=>$invoice_id],'more_info',$fields,'id');
		
		$this->load->view('invoice',$data);
	}
	function generatepdf($invoice_id){
		
		// convert to pdf
		$this->load->library('pdf');
			
		$data = $this->generate($invoice_id);
		$html = $this->load->view('invoicepdf', $data, true);
		
		$this->pdf->createPDF($html, 'mypdf', false);
		
		
	}
	

	private function add($data,$table) { // common function for add data to table
		$this->validation_assign();
  		if($this->form_validation->run()==TRUE) { //print_r($data);echo "hi";exit;
  			$data = $this->invoice_model->add_without_check($data,$table);
			return $data;
  		}
    	return $data;
    }
		


	
	

	

	

}