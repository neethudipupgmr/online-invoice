<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<!-- jQuery -->
<title>Online Invoice Generator</title>
<script type="text/javascript" src="<?=base_url()?>assets/js/form.js"></script>
	
	</head>
	<body>
		
	

		<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!--Author      : @arboshiki-->

<style>
#invoice{
    padding: 30px;
}

.invoice {
    position: relative;
    background-color: #FFF;
    min-height: 680px;
    padding: 15px
}

.invoice header {
    padding: 10px 0;
    margin-bottom: 20px;
    border-bottom: 1px solid #3989c6
}

.invoice .company-details {
    text-align: right
}

.invoice .company-details .name {
    margin-top: 0;
    margin-bottom: 0
}

.invoice .contacts {
    margin-bottom: 20px
}

.invoice .invoice-to {
    text-align: left
}

.invoice .invoice-to .to {
    margin-top: 0;
    margin-bottom: 0
}

.invoice .invoice-details {
    text-align: right
}

.invoice .invoice-details .invoice-id {
    margin-top: 0;
    color: #3989c6
}

.invoice main {
    padding-bottom: 50px
}

.invoice main .thanks {
    margin-top: -100px;
    font-size: 2em;
    margin-bottom: 50px
}

.invoice main .notices {
    padding-left: 6px;
    border-left: 6px solid #3989c6
}

.invoice main .notices .notice {
    font-size: 1.2em
}

.invoice table {
    width: 100%;
    border-collapse: collapse;
    border-spacing: 0;
    margin-bottom: 20px
}

.invoice table td,.invoice table th {
    padding: 15px;
    background: #eee;
    border-bottom: 1px solid #fff
}

.invoice table th {
    white-space: nowrap;
    font-weight: 400;
    font-size: 16px
}

.invoice table td h3 {
    margin: 0;
    font-weight: 400;
    color: #3989c6;
    font-size: 1.2em
}

.invoice table .qty,.invoice table .total,.invoice table .unit {
    text-align: right;
    font-size: 1.2em
}

.invoice table .no {
    color: #fff;
    font-size: 1.6em;
    background: #3989c6
}

.invoice table .unit {
    background: #ddd
}

.invoice table .total {
    background: #3989c6;
    color: #fff
}

.invoice table tbody tr:last-child td {
    border: none
}

.invoice table tfoot td {
    background: 0 0;
    border-bottom: none;
    white-space: nowrap;
    text-align: right;
    padding: 10px 20px;
    font-size: 1.2em;
    border-top: 1px solid #aaa
}

.invoice table tfoot tr:first-child td {
    border-top: none
}

.invoice table tfoot tr:last-child td {
    color: #3989c6;
    font-size: 1.4em;
    border-top: 1px solid #3989c6
}

.invoice table tfoot tr td:first-child {
    border: none
}

.invoice footer {
    width: 100%;
    text-align: center;
    color: #777;
    border-top: 1px solid #aaa;
    padding: 8px 0
}

@media print {
    .invoice {
        font-size: 11px!important;
        overflow: hidden!important
    }

    .invoice footer {
        position: absolute;
        bottom: 10px;
        page-break-after: always
    }

    .invoice>div:last-child {
        page-break-before: always
    }
}</style>
		
			<div class="container">
	<a href="<?=site_url('home/generatepdf/'.$id)?>" class="btn btn-primary">Download</a>
			<?php /*?><a href="<?=site_url('home/edit_invoice/'.$id)?>" class="btn btn-danger">Edit</a><?php */?>
		</div>
		
<div id="invoice">

  
    <div class="invoice overflow-auto">
        <div style="min-width: 600px">
            <header>
                <div class="row">
                  
                    <div class="col company-details">
                        <h2 class="name">
                            <a target="_blank" href="#">
                            <?=$company_name?>
                            </a>
                        </h2>
                        <div><?=$company_address?></div>
                        <div><?=$company_phone?></div>
                        <div><?=$company_email?></div>
                    </div>
                </div>
            </header>
            <main>
                <div class="row contacts">
                    <div class="col invoice-to">
                        <div class="text-gray-light">INVOICE TO:</div>
                        <h2 class="to"><?=$customer_name?></h2>
                        <div class="address"><?=$customer_address?></div>
                        <div class="email"><a href=""><?=$customer_email?></a></div>
                    </div>
                    <div class="col invoice-details">
                        <h1 class="invoice-id"><?=$invoice_id?></h1>
                        <div class="date">Date of Invoice: <?=$invoice_date?></div>
                        
                    </div>
                </div>
                <table border="0" cellspacing="0" cellpadding="0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th class="text-left">NAME</th>
                            <th class="text-right">QUANTITY</th>
                            <th class="text-right">UNIT PRICE</th>
                            <th class="text-right">TOTAL AMOUNT WITHOUT TAX</th>
							<th class="text-right">TAX</th>
							<th class="text-right">TOTAL AMOUNT WITH TAX</th>
                        </tr>
                    </thead>
                    <tbody>
																						<?php 
	$TotalAmountwithouttax = 0;
	$TotalAmountwithtax=0;
											$subtotalwithouttax = 0;
											$subtotalwithtax = 0;
		$count = 0;
											
	foreach($res->result() as $row){ $count++;
																	
						$TotalAmountwithouttax = $row->item_price*$row->item_quantity;
									$item_tax = $row->item_tax;
									if($item_tax == 0){
										$tax = 0;
									}else if($item_tax == 2){
										$tax = 1;
									}else if($item_tax == 3){
										$tax = 5;
									}else{
										$tax = 10;
									}
						
		 $tax1_amount = $TotalAmountwithouttax * $tax/100;
		$TotalAmountwithtax = $TotalAmountwithouttax + $tax1_amount;
		
		$subtotalwithouttax = $subtotalwithouttax + $TotalAmountwithouttax;
		$subtotalwithtax = $subtotalwithtax + $TotalAmountwithtax;
		
																	
																	?>
                        <tr>
                            <td class="no"><?=$count?></td>
                            <td class="text-left">
                                <?=$row->item_name?>
                            </td>
                            <td class="quantity"><?=$row->item_quantity?></td>
                            <td class="price">$<?=$row->item_price?></td>
                            <td class="totalwithouttax">$<?=$TotalAmountwithouttax?></td>
							<td class="tax">
								<?php if($row->item_tax == 0){ echo "0%";} else if($row->item_tax == 2){ echo "1%"; } else if($row->item_tax == 3){ echo "5%";}else{ echo "10%";}?>
								
								
								</td>
							<td class="totalwithtax">$<?=$TotalAmountwithtax?></td>
                        </tr>
                        
                        <?php } ?>
                        
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="2"></td>
                            <td colspan="2">Sub Total Without Tax</td>
                            <td>$<?=$subtotalwithouttax?></td>
                        </tr>
                        <tr>
                            <td colspan="2"></td>
                            <td colspan="2">DISCOUNT</td>
                            <td>
							
							<?php if($discount_type == 1){
																
		$reduce_discount = ($subtotalwithtax * $discount_value) /100;
			$grandtotal = $subtotalwithtax - $reduce_discount;
			
																
																?>
																<?=$discount_value?>
																
																<?php }else{
																
																
										$grandtotal = $subtotalwithtax - $discount_value_amount;?>
																
																<?=$discount_value_amount?>
	
	
	
	<?php
} ?><span><?php if($discount_type == 1){?>%<?php }else{?>$<?php } ?></span>
							</td>
                        </tr>
						
						 <tr>
                            <td colspan="2"></td>
                            <td colspan="2">Sub Total With Tax</td>
                            <td>$<?=$subtotalwithtax?></td>
                        </tr>
						
						
                        <tr>
                            <td colspan="2"></td>
                            <td colspan="2">GRAND TOTAL</td>
                            <td><?=$grandtotal?></td>
                        </tr>
                    </tfoot>
                </table>
             
            </main>
          
        </div>
        <!--DO NOT DELETE THIS div. IT is responsible for showing footer always at the bottom-->
        <div></div>
    </div>
</div>