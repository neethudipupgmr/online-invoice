<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<!-- jQuery -->
<title>Online Invoice Generator</title>
<script type="text/javascript" src="<?=base_url()?>assets/js/form.js"></script>

<style type="text/css">
  #user_form fieldset:not(:first-of-type) {
    display: none;
  }
	.has-error{
		border-color: #F5090D;
	}
</style>
</head>
<body class="">
<div role="navigation" class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        
        </div>
        <div class="navbar-collapse collapse">
        
         
        </div><!--/.nav-collapse -->
      </div>
    </div>
	
	<div class="container" style="min-height:500px;">
	<div class=''>
	</div>

<div class="container">
	<h2>Online Invoice Generator</h2>		
	
	<div class="alert alert-success hide"></div>	
	<form id="user_form" novalidate action="<?=site_url('form_action')?>"  method="post">	
	
	<fieldset>
	
	<h3>Company Details</h3>
		<div class="form-group col-sm-4">
	<label for="Company Name">Company Name*</label>
	<input type="text" class="form-control <?=form_error('company_name'); ?>" value="<?=$company_name?>" name="company_name" id="company_name" placeholder="Company Name">
	</div>
		
		
		
		<div class="form-group col-sm-4">
	<label for="Address">Address*</label>
	<textarea class="form-control <?=form_error('company_address'); ?>" name="company_address" id="company_address" placeholder="Address"><?=$company_address?></textarea>
	</div>
		
		
		
		
		
		<div class="form-group col-sm-4">
	<label for="phone">Phone*</label>
	<input type="text" class="form-control <?=form_error('company_phone'); ?>" value="<?=$company_phone?>" name="company_phone" id="company_phone" placeholder="Phone">
	</div>
		
		<div class="form-group col-sm-4">
	<label for="email">Email</label>
	<input type="email" class="form-control" name="company_email" value="<?=$company_email?>" id="company_email" placeholder="Email">
	</div>
		
		
		<hr/>
		
		<h3>Customer Details</h3>
		
		<div class="form-group col-sm-4">
	<label for="Customer Name">Customer Name*</label>
	<input type="text" class="form-control <?=form_error('customer_name'); ?>" value="<?=$customer_name?>" name="customer_name" id="customer_name" placeholder="Customer Name">
	</div>
		
		
		
		<div class="form-group col-sm-4">
	<label for="Address">Address*</label>
			<textarea class="form-control <?=form_error('customer_address'); ?>" name="customer_address" id="customer_address" placeholder="Address"><?=$customer_address?></textarea>

	</div>
		
		
		<?php //echo validation_errors(); ?>

		
		
		
		
		<div class="form-group col-sm-4">
	<label for="phone">Phone*</label>
	<input type="text" class="form-control <?=form_error('customer_phone'); ?>" value="<?=$customer_phone?>" name="customer_phone" id="customer_phone" placeholder="Phone">
	</div>
		<div class="form-group col-sm-4">
			<label for="email">Email</label>
	<input type="email" class="form-control" name="customer_email" value="<?=$customer_email?>" id="customer_email" placeholder="Phone">
		</div>
		
	<hr/>
		
		<h3>Invoice Details</h3>	
		
		
	<div class="form-group col-sm-4">
	<label for="title">Title</label>
	<input type="text" class="form-control" name="title" value="<?=$title?>" id="title" placeholder="Invoice Title">
	</div>
	<div class="form-group col-sm-4">
	<label for="title">Inovice Date*</label>
	<input type="date" class="form-control <?=form_error('invoice_date'); ?>" value="<?=$invoice_date?>" name="invoice_date" id="invoice_date" placeholder="Invoice Title">
	</div>
		
	
		
		<section class="container">
<div class="table table-responsive">
	
	

	
	
	
<table class="table table-responsive table-striped table-bordered">
<thead>
	<tr>
    	<td>Name</td>
    	<td>Quantity</td>
    	<td>Unit Price</td>
		
		<td>Total Amount without tax</td>
    	<td>Tax</td>
		<td>Total Amount with tax</td>
		<td></td>
    </tr>
</thead>
<tbody id="TextBoxContainer">
	
	
	<?php 
	$count=0; //echo $discount_value_amount;
		   $TotalAmountwithouttax = 0;
	$TotalAmountwithtax=0;
		$subtotalwithouttax = 0;
											$subtotalwithtax = 0;
	foreach($res->result() as $row){ $count++;
	
			
									
									
									
	
	?>
	
	<td><input type="hidden" value="<?=$count?>" name="count" id="countbox">
		<input name = "item_name[]" value="<?=$row->item_name?>" type="text" id ="item_name<?=$count?>" class="form-control item_name" /></td><td><input value="<?=$row->item_quantity?>" name = "item_quantity[]" type="text" id ="item_quantity<?=$count?>" data-srno="<?=$count?>" class="form-control item_quantity" /></td><td><input value="<?=$row->item_price?>" name = "item_price[]" type="text" id ="item_price<?=$count?>" data-srno="<?=$count?>" class="form-control item_price" /></td><td><input value="$TotalAmountwithouttax" disabled name = "item_total[]" type="text" id ="item_total<?=$count?>" data-srno="<?=$count?>" class="form-control item_total" /></td><td>
	<select name="item_tax[]" id ="item_tax<?=$count?>" class="form-control item_tax">
		<option value="0"> 0%</option>
		<option value="2" <?php if($row->item_tax == 1){?> selected <?php } ?>> 1%</option>
		<option value="3" <?php if($row->item_tax == 2){?> selected <?php } ?>>5%</option>
		<option value="4" <?php if($row->item_tax == 3){?> selected <?php } ?>>10%</option>
	</select></td><td><input disabled name ="item_actual_total[]" type="text" value="TotalAmountwithtax" id ="item_actual_total<?=$count?>" class="form-control item_actual_total" /></td><td><button type="button" class="btn btn-danger remove"><i class="glyphicon glyphicon-remove-sign"></i></button></td>
	
	<?php } ?>
	
	
</tbody>
<tfoot>
  <tr>
    <th colspan="7">  <input type="hidden" name="total_item" id="total_item" value="0" />
    <button id="btnAdd" type="button" class="btn btn-primary" data-toggle="tooltip" data-original-title="Add more controls"><i class="glyphicon glyphicon-plus-sign"></i>&nbsp; Add&nbsp;</button></th>
  </tr>
	
	
	<tr>
    <th colspan="3"> 
		Sub Total Without Tax
		
  </th>
		<th colspan="5">
		<span id="subtotalwithouttax"><?=$subtotalwithouttax?></span><input type="hidden" id="formsubtotalwithouttax" value="<?=$subtotalwithouttax?>">
		</th>
	  
  </tr>
	
	<tr>
	
	<th>Discount Type</th>
		<th><select name="discount_type" id ="discount_type" class="form-control discount_type"><option value="0"> Select</option><option <?php if($discount_type == 1){?> selected <?php } ?> value="1"> Percentage%</option><option <?php if($discount_type == 2){?> selected <?php } ?> value="2">Amount₹</option></select></th>
	<th >
		
		<?php if($discount_type == 1){?>
		
		<div id="display_discount_percent_value">
		<div class="form-group">
			
			<input type='text' class="form-control discount_value" id="discount_value" value="<?=$discount_value?>"name="discount_value"/>
			
		
		</div>
		</div>
		<?php }else{ ?>
		
			<div id="display_discount_amount_value">
		<div class="form-group">
		<input type="text" value="<?=$discount_value_amount?>" class="form-control discount_value" name="discount_value_amount" id="discount_value_amount">
		</div></div>
		
		<?php } ?>
		<div id="display_discount_percent_value" style="display: none;">
		<div class="form-group">
			
			<input type='text' class="form-control discount_value" id="discount_value" name="discount_value"/>
			
		
		</div>
		</div>
		
			<div id="display_discount_amount_value" style="display: none;">
		<div class="form-group">
		<input type="text" value="" class="form-control discount_value" name="discount_value_amount" id="discount_value_amount">
		</div></div>
		
		</th>
		
		
	</tr>
	
	<tr>
    <th colspan="5"> 
		Sub Total With Tax
		
  </th>
		<th colspan="2">
		<span id="subtotalwithtax"><?=$subtotalwithtax?></span><input type="hidden" id="formsubtotalwithtax" value="<?=$subtotalwithtax?>">
		</th>
	  
  </tr>
	
	<?php if($discount_type == 1){
																
		$reduce_discount = ($subtotalwithtax * $discount_value) /100;
			$grandtotal = $subtotalwithtax - $reduce_discount;
			
																
																?>
																<?=$discount_value?>
																
																<?php }else{
																
																
										$grandtotal = $subtotalwithtax - $discount_value_amount;?>
																
																
	
	
	
	<?php
} ?>
	
	<tr>
    <th colspan="5"> 
		Grand Total
		
  </th>
		<th colspan="2">
		<span id="grandtotal"><?=$grandtotal?></span>
		</th>
	  
  </tr>
</tfoot>
	
	
</table>
</div>
</section>
		
		
		
	<?php /*?><input type="button" name="previous" class="previous btn btn-default" value="Previous" /><?php */?>
	<input type="submit" name="submit" class="submit btn btn-success" value="Generate Invoice" />
	</fieldset>
	</form>
		
		
		
	<div style="margin:50px 0px 0px 0px;">
					
	</div>	
</div>	
<div class="insert-post-ads1" style="margin-top:20px;">

</div>
</div>
</body></html>

