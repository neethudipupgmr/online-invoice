<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Invoice { 

var $url = '';
private $email = '';
public $mail_body = '';
public $subject = '';
public $cc = '';

function __construct() {
		$this->url = "http://".$_SERVER['HTTP_HOST'].'/';
		
}
function get_current_time() { // function for get date
	date_default_timezone_set('Asia/Kolkata');
	$now=date("Y-m-d H:i:s");
	return $now;
}

function get_current_date() { // function for get current date
	date_default_timezone_set('Asia/Kolkata');
	$now=date("Y-m-d");
	return $now;
}

function getUniqueID($length=4){ // function get unique ids
        $random= ""; 
        srand((double)microtime()*1000000); 
        $data = "AbcDE123IJKLMN67QRSTUVWXYZ"; 
        $data .= "aBCdefghijklmn123opq45rs67tuv89wxyz"; 
        $data .= "0FGH45OP89"; 
        for($i = 0; $i < $length; $i++) 
        { 
         $random .= substr($data, (rand()%(strlen($data))), 1); 
        } 
        return $random.date("ymd"); 
}

}

?>