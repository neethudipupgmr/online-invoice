$(document).ready(function(){ 
	
	
	
	
	
  var form_count = 1, form_count_form, next_form, total_forms;
  total_forms = $("fieldset").length;  
  $(".next").click(function(){
    form_count_form = $(this).parent();
    next_form = $(this).parent().next();
    next_form.show();
    form_count_form.hide();
    setProgressBar(++form_count);
  });  
  $(".previous").click(function(){
    form_count_form = $(this).parent();
    next_form = $(this).parent().prev();
    next_form.show();
    form_count_form.hide();
    setProgressBar(--form_count);
  });
  setProgressBar(form_count);  
  function setProgressBar(curStep){
    var percent = parseFloat(100 / total_forms) * curStep;
    percent = percent.toFixed();
    $(".progress-bar")
      .css("width",percent+"%")
      .html(percent+"%");   
  } 
  // Handle form submit and validation
  $( "#user_form" ).submit(function(event) {    
	var error_message = '';
	if(!$("#company_name").val()) {
		error_message+="Please Fill company name";
		
		$("#company_name").addClass("has-error");
		
		
	}
	if(!$("#company_address").val()) {
		error_message+="<br>Please Fill Company Address";
		$("#company_address").addClass("has-error");
	}
	if(!$("#company_phone").val()) {
		error_message+="<br>Please Fill Company Contact Number";
		$("#company_phone").addClass("has-error");
	}
	  
	  if(!$("#customer_name").val()) {
		error_message+="<br>Please Fill Customer Name";
		  $("#customer_name").addClass("has-error");
	}
	  
	  
	  if(!$("#customer_address").val()) {
		  error_message+="<br>Please Fill Customer Address";
		  $("#customer_address").addClass("has-error");
	}
	  
	   
	  if(!$("#customer_phone").val()) {
		error_message+="<br>Please Fill Customer Contact Number";
		  $("#customer_phone").addClass("has-error");
	}
	  
	    
	  if(!$("#title").val()) {
		error_message+="<br>Please Fill Invoice Title";
		  $("#title").addClass("has-error");
	}
	  
	     
	  if(!$("#invoice_date").val()) {
		error_message+="<br>Please Fill Invoice Date";
		  $("#invoice_date").addClass("has-error");
	}
	  
	  
	  
	// Display error if any else submit form
	if(error_message) {
		$('.alert-success').removeClass('hide').html(error_message);
		return false;
	} else {
		return true;	
	}    
  });  
});

$(function () {
	
	
	var count = 0;
	
    $("#btnAdd").bind("click", function () { 
		
		 count++;
        
        var div = $("<tr />");
        div.html(GetDynamicTextBox(count));
        $("#TextBoxContainer").append(div);
    });
    $("body").on("click", ".remove", function () {
        $(this).closest("tr").remove();
    });
	
	
	
	$(document).on('blur', '.item_price', function(){
		
          calculate_final_total(count);
        });
	
	
	$(document).on('blur', '.item_quantity', function(){
		
          calculate_final_total(count);
        });
	
	
	
	
	$(document).on('change', '.item_tax', function(){ 
          calculate_final_total(count);
        });
	
	$(document).on('change', '.discount_type', function(){ 
		var discount_type = $('#discount_type').val();
		if(discount_type == 1){
			$('#display_discount_percent_value').fadeToggle();
			$('#display_discount_amount_value').fadeOut();
		}else{
			$('#display_discount_amount_value').fadeToggle();
			$('#display_discount_percent_value').fadeOut();
		}
          
        });
	
	
	$(document).on('blur', '.discount_value', function(){
		calculate_final_total(count);
		
        });
	
	
	
	
});






 function calculate_final_total(count)
        {
			// automatic calculation are done here
         
			 var quantity = 0;
            var price = 0;
            var item_total = 0;
			  var item_tax = 0;
			  var tax1_amount = 0;
			var tax = 0;
            var j = 0;
			var item_actual_total = 0;
			var subtotalwithouttax = 0;
			var subtotalwithtax = 0;
			var grandtotal = 0;
			var reduce_discount = 0;
          for(j=1; j<=count; j++)
          {
           
            quantity = $('#item_quantity'+j).val();
            if(quantity > 0)
            {
              price = $('#item_price'+j).val();
              if(price > 0)
              {
                item_total = parseFloat(quantity) * parseFloat(price); // calculate item total price
				  
				  
				  
                $('#item_total'+j).val(item_total);
				  $('#item_actual_total'+j).val(0); 
				  
				  
				  
				  
				
				  
				 item_tax = $('#item_tax'+j).val();
				
            if(item_tax > 0)
              {
				  if(item_tax == 1){ tax = 0;}
				  else if(item_tax == 2){ tax = 1;}
				  else if(item_tax == 3){ tax = 5;}
				  else if(item_tax == 4){ tax = 10;}
				 
				  tax1_amount = parseFloat(item_total)*parseFloat(tax)/100; // calculate tax amount
				 			  
				   item_actual_total = parseFloat(item_total) + parseFloat(tax1_amount); // sum of total with tax for each item
				  			  
				   $('#item_actual_total'+j).val(item_actual_total);
                 
			  }
				  
				  
				  
				  subtotalwithouttax = parseFloat(subtotalwithouttax) + parseFloat(item_total); // calculate sub total with out tax
				  subtotalwithtax = parseFloat(subtotalwithtax) + parseFloat(item_actual_total);// calculate sub total with tax
               
              }
				
				
				
				
				
				
				
				
				
				
            }
          }
			
			 $('#subtotalwithouttax').text(subtotalwithouttax);
			 $('#formsubtotalwithouttax').val(subtotalwithouttax);
			$('#subtotalwithtax').text(subtotalwithtax);
			 $('#formsubtotalwithtax').val(subtotalwithtax);
			
			
			
			var discount_type = $('#discount_type').val();
			
			if(discount_type == 1){
				
				var discount_value = $('#discount_value').val();
		
		if(subtotalwithtax == 0){
			
			reduce_discount = parseFloat(subtotalwithouttax)*parseFloat(discount_value)/100;// discount calculation
			grandtotal = subtotalwithouttax - reduce_discount; //calculate grand total
			
			
		}else{
		
			
			reduce_discount = parseFloat(subtotalwithtax)*parseFloat(discount_value)/100;
			grandtotal = subtotalwithtax - reduce_discount;
				
		}
			
			
		}else if(discount_type == 2){ 
			var discount_value_amount = $('#discount_value_amount').val();
			if(subtotalwithtax == 0){
				grandtotal = subtotalwithouttax - discount_value_amount;
			
			}else{
				
			
			grandtotal = subtotalwithtax - discount_value_amount;
			}
			
			
			
		}else{
			if(item_tax > 0)
              {
				  grandtotal = subtotalwithtax;
			  }
			else{
				
			
			
			
			grandtotal = subtotalwithouttax;
			}
		}
			
			$('#grandtotal').text(grandtotal);
         
        }

function GetDynamicTextBox(value) { // function for add line items
    return '<td><input name = "item_name[]" type="text" id ="item_name'+value+'" class="form-control item_name" /></td>' + '<td><input name = "item_quantity[]" type="text" id ="item_quantity'+value+'" data-srno="'+value+'" class="form-control item_quantity" /></td>' + '<td><input name = "item_price[]" type="text" id ="item_price'+value+'" data-srno="'+value+'" class="form-control item_price" /></td>'+ '<td><input disabled name = "item_total[]" type="text" id ="item_total'+value+'" data-srno="'+value+'" class="form-control item_total" /></td>'  + '<td><select name="item_tax[]" id ="item_tax'+value+'" data-srno="'+value+'" class="form-control item_tax"><option value="0" selected> 0%</option><option value="2">1%</option><option value="3">5%</option><option value="4">10%</option></select></td>' + '<td><input disabled name = "item_actual_total[]" type="text" id ="item_actual_total'+value+'" data-srno="'+value+'" class="form-control item_actual_total" /></td>' + '<td><button type="button" class="btn btn-danger remove"><i class="glyphicon glyphicon-remove-sign"></i></button></td>'
}