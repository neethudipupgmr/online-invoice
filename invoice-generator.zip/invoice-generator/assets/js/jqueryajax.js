// JavaScript Document
$(document).ready(function() {	
  Init(); 
});

function Init(){
	$(".add").on('click',function() {
    alert("hi");

 //var id = $(this).attr('id');
//
////alert(id);
// var offset = $(this).attr('name');
//     //alert(offset);
//     var action = $(this).attr('class');
//     //alert(action);
//
//     var page = CI.page;
//     //alert(page);
//
// var data = { id: id, page:page, action:action, offset:offset };
//   alert(CI.base_url);
//
// ajax_form(CI.base_url+'action',data);

})
	
}