$(function(){
	$("#wizard").steps({
        headerTag: "h4",
        bodyTag: "section",
        transitionEffect: "fade",
        enableAllSteps: true,
        transitionEffectSpeed: 500,
        onStepChanging: function (event, currentIndex, newIndex) { 
            if ( newIndex === 1 ) {
                $('.steps ul').addClass('step-2');
				
				
            } else {
                $('.steps ul').removeClass('step-2');
            }
            if ( newIndex === 2 ) {
                $('.steps ul').addClass('step-3');
				
            } else {
                $('.steps ul').removeClass('step-3');
            }

            if ( newIndex === 3 ) { 
				$('.steps ul').addClass('step-4');
								 
                $('.actions ul').addClass('step-last');
            } else { 
                $('.steps ul').removeClass('step-4');
                $('.actions ul').removeClass('step-last');
            }
            return true; 
        },
		onFinished: function (event, currentIndex) {
			 
		var base_url = $("#base_url").val()	;
			var company_name = $("#company_name").val()	;
			var addressone = $("#addressone").val()	;
			var addresstwo = $("#addresstwo").val()	;
			var postalcode = $("#postalcode").val()	;
			var town = $("#town").val()	;
					
			$.ajax({
        type: 'POST',
      url :base_url,
				data:  {company_name:company_name,addressone:addressone,addresstwo:addresstwo,postalcode:postalcode,town:town}, 
            success:function(resp){
           alert(resp);
           
        }
    });
		},
        labels: {
            finish: "Generate Invoice",
            next: "Next",
            previous: "Previous"
        }
    });
    // Custom Steps Jquery Steps
    $('.wizard > .steps li a').click(function(){ 
    	$(this).parent().addClass('checked');
		$(this).parent().prevAll().addClass('checked');
		$(this).parent().nextAll().removeClass('checked');
    });
    // Custom Button Jquery Steps
    $('.forward').click(function(){ //alert("1");
    	$("#wizard").steps('next');
    })
    $('.backward').click(function(){ //alert("2")
        $("#wizard").steps('previous');
    })
    // Checkbox
    $('.checkbox-circle label').click(function(){ //alert("3");
        $('.checkbox-circle label').removeClass('active');
        $(this).addClass('active');
    })
})
