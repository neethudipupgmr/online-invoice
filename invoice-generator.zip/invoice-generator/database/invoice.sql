-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 17, 2021 at 05:40 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `invoice`
--

-- --------------------------------------------------------

--
-- Table structure for table `invoice_info`
--

CREATE TABLE `invoice_info` (
  `id` int(11) NOT NULL,
  `invoice_id` varchar(250) NOT NULL,
  `company_name` varchar(250) NOT NULL,
  `company_address` text NOT NULL,
  `company_phone` varchar(250) NOT NULL,
  `company_email` varchar(250) NOT NULL,
  `customer_name` varchar(250) NOT NULL,
  `customer_address` varchar(250) NOT NULL,
  `customer_phone` varchar(250) NOT NULL,
  `customer_email` varchar(250) NOT NULL,
  `title` varchar(250) NOT NULL,
  `invoice_date` varchar(250) NOT NULL,
  `discount_type` int(11) NOT NULL,
  `discount_value` float NOT NULL,
  `discount_value_amount` float NOT NULL,
  `entry_date` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice_info`
--

INSERT INTO `invoice_info` (`id`, `invoice_id`, `company_name`, `company_address`, `company_phone`, `company_email`, `customer_name`, `customer_address`, `customer_phone`, `customer_email`, `title`, `invoice_date`, `discount_type`, `discount_value`, `discount_value_amount`, `entry_date`, `status`) VALUES
(1, 'qfFe210617', 'stepsonweb', 'eranakulam', '9495773998', 'neethu@stepsonweb.com', 'neethu', 'idukki,kavana, kavana, kavana, kavana\r\nkavana', '9495773998', 'neethu@stepsonweb.com', 'Section 1.10.32 of \"de Finibus Bonorum et Malorum\", written by Cicero in 45 BC', '2021-06-18', 1, 2, 0, '2021-06-17', 1),
(2, '2Unk210617', 'neethu', 'kerala\r\nkerala', '9495773998', 'neethu@stepsonweb.com', 'test sow', 'parackal\r\nkavana', '9961434074', 'neethu@stepsonweb.com', 'Tips For Business Success 2017: Why To Online', '2021-06-18', 1, 2, 0, '2021-06-17', 1);

-- --------------------------------------------------------

--
-- Table structure for table `more_info`
--

CREATE TABLE `more_info` (
  `id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `item_name` varchar(250) NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `item_price` float NOT NULL,
  `item_tax` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `more_info`
--

INSERT INTO `more_info` (`id`, `invoice_id`, `item_name`, `item_quantity`, `item_price`, `item_tax`) VALUES
(1, 1, 'computer', 1, 15000, 2),
(2, 2, 'computer', 1, 15000, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `invoice_info`
--
ALTER TABLE `invoice_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `more_info`
--
ALTER TABLE `more_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `invoice_info`
--
ALTER TABLE `invoice_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `more_info`
--
ALTER TABLE `more_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
